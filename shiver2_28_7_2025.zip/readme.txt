Models & Textures:
- Falanta (Discord: @falanta, Email: falantafantomo@gmail.com)
- 2M3V (Discord: @2m3v, Email: mentusik02316@gmail.com)
- https://www.planetminecraft.com/texture-pack/hananacraft-v1-0/

Cinematic lines shader:
- DartCat25(Discord @dartcat25)

Sounds used from:
- Team Fortress 2
- Left4Dead 2
- Half-life 2
- Black Mesa
- Outlast
- Amnesia
- Fallout 4
- open internet resources

Taken as an idea:
- Zombie Survival (Garry's mod)

Resource Pack by 2M3V
Build: 28 Jul 2025